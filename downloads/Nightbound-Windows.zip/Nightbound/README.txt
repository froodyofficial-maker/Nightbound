Nightbound for Windows
======================

1. Unzip this folder anywhere (for example your Desktop).
2. Double-click Nightbound.exe (keep resources.neu in the same folder).

- Needs Windows 10 or 11 and an internet connection. It always runs the latest version of the game.
- Windows may show "Windows protected your PC" because the app is not code-signed. Click "More info", then "Run anyway".
- Your progress is saved inside the app, separately from the browser version.
